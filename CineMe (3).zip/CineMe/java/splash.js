
// CineMe Productions - fast logo introduction

(function () {
    'use strict';

    // Logo timing
    var DISPLAY_TIME = 1100;
    var FADE_TIME = 300;

    var isNavigating = false;

    // Find the splash.js file.
    var scriptFile = document.querySelector('script[src$="splash.js"]');

    // Find the logo using the splash.js location.
    var logoPath = new URL(
        '../images/cineme-logo-transparent.png',
        scriptFile.src
    ).href;


    // Create the logo screen.
    function createSplash() {

        var splash = document.createElement('div');

        splash.className = 'cineme-splash';

        var logo = document.createElement('img');

        logo.src = logoPath;
        logo.alt = 'CineMe Productions';
        logo.className = 'cineme-splash-logo';

        splash.appendChild(logo);

        document.body.appendChild(splash);

        return {
            screen: splash,
            image: logo
        };
    }


    // Show the logo and remove it after the animation.
    function showSplash(afterClear) {

        document.documentElement.classList.add('cineme-splash-pending');

        var splashData = createSplash();
        var splash = splashData.screen;
        var logo = splashData.image;

        var started = false;

        function finish() {

            if (splash.parentNode) {
                splash.parentNode.removeChild(splash);
            }

            document.documentElement.classList.remove('cineme-splash-pending');

            if (typeof afterClear === 'function') {
                afterClear();
            }
        }


        function startAnimation() {

            if (started) {
                return;
            }

            started = true;

            window.requestAnimationFrame(function () {

                splash.classList.add('is-visible');

                window.setTimeout(function () {

                    splash.classList.add('is-leaving');

                    window.setTimeout(finish, FADE_TIME);

                }, DISPLAY_TIME);

            });
        }


        // Wait for the logo to load before showing it.
        logo.onload = startAnimation;

        // Do not leave the page hidden if the logo cannot load.
        logo.onerror = function () {

            console.error('CineMe logo could not be loaded:', logoPath);

            finish();

        };

        // Handle an image that has already loaded.
        if (logo.complete && logo.naturalWidth > 0) {
            startAnimation();
        }
    }


    // Check whether navigation already displayed the logo.
    var skipSplash = false;

    try {

        skipSplash =
            sessionStorage.getItem('cinemeSkipSplash') === 'true';

        if (skipSplash) {
            sessionStorage.removeItem('cinemeSkipSplash');
        }

    } catch (error) {
        skipSplash = false;
    }


    // Show the logo when opening the website.
    if (skipSplash) {

        document.documentElement.classList.remove('cineme-splash-pending');

    } else {

        showSplash();

    }


    // Show the logo before moving to another page.
    document.addEventListener('click', function (event) {

        var link = event.target.closest('a[href]');

        if (!link || isNavigating || event.defaultPrevented) {
            return;
        }

        if (
            event.button !== 0 ||
            event.ctrlKey ||
            event.shiftKey ||
            event.altKey ||
            event.metaKey
        ) {
            return;
        }

        if (link.target && link.target !== '_self') {
            return;
        }

        if (link.hasAttribute('download')) {
            return;
        }

        var destination = new URL(link.href, window.location.href);

        // Only use the animation for local HTML pages.
        if (
            destination.origin !== window.location.origin ||
            !/\.html?$/i.test(destination.pathname)
        ) {
            return;
        }

        // Ignore links to the current page.
        if (
            destination.pathname === window.location.pathname &&
            destination.search === window.location.search
        ) {
            return;
        }

        event.preventDefault();

        isNavigating = true;

        try {
            sessionStorage.setItem('cinemeSkipSplash', 'true');
        } catch (error) {
            // Continue navigating if storage is unavailable.
        }

        showSplash(function () {

            window.location.href = destination.href;

        });

    });

})();