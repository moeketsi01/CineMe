 // CineMe Productions - interactive features
// 1. Page-ready flag   2. Current page in nav   3. Scroll reveal
// 4. FAQ accordion (jQuery)   5. Gallery filter tabs (jQuery)
// 6. Lightbox   7. Leaflet map

(function () {
    'use strict';

    // 1. Tell the page this script loaded (the snippet in each <head> checks this)
    window.cinemeReady = true;

    var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;


    // 2. Mark the current page in the navigation
    function markCurrentPage() {
        var currentPage = window.location.pathname.split('/').pop() || 'index.html';

        document.querySelectorAll('nav a').forEach(function (link) {
            var target = link.getAttribute('href').split('/').pop();
            if (target === currentPage) {
                link.setAttribute('aria-current', 'page');
            }
        });
    }


    // 3. Scroll reveal - sections fade up as they enter the screen
    function initReveal() {
        var targets = document.querySelectorAll('main section:not(.hero)');

        if (prefersReduced || !('IntersectionObserver' in window)) {
            targets.forEach(function (el) {
                el.classList.add('in-view');
            });
            return;
        }

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0, rootMargin: '0px 0px -60px 0px' });

        targets.forEach(function (el) {
            observer.observe(el);
        });
    }


    // 4. FAQ accordion (jQuery) - one panel open at a time
    function initAccordion($) {
        var $accordion = $('.accordion');
        if (!$accordion.length) {
            return;
        }

        var $panels = $accordion.find('.accordion-panel').hide();

        $accordion.on('click', '.accordion-trigger', function () {
            var $trigger = $(this);
            var $panel = $('#' + $trigger.attr('aria-controls'));
            var isOpen = $trigger.attr('aria-expanded') === 'true';

            $accordion.find('.accordion-trigger').not($trigger).attr('aria-expanded', 'false');
            $panels.not($panel).stop(true, true).slideUp(250);

            $trigger.attr('aria-expanded', String(!isOpen));

            if (isOpen) {
                $panel.stop(true, true).slideUp(250);
            } else {
                $panel.stop(true, true).slideDown(250);
            }
        });
    }


    // 5. Gallery filter tabs (jQuery) - the filter bar is built from the images' data-category
    function initGalleryFilter($) {
        var $grid = $('.gallery-grid');
        var $items = $grid.find('img[data-category]');
        if (!$grid.length || !$items.length) {
            return;
        }

        var order = ['crew', 'editing', 'drone', 'lighting', 'photography', 'sound', 'stage', 'stills'];
        var labels = {
            crew: 'Crew',
            editing: 'Video Editing',
            drone: 'Drone',
            lighting: 'Lighting',
            photography: 'Photography',
            sound: 'Sound',
            stage: 'Stage',
            stills: 'Stills'
        };

        var counts = {};
        $items.each(function () {
            var key = $(this).attr('data-category');
            counts[key] = (counts[key] || 0) + 1;
        });

        var $bar = $('<div class="filter-bar" role="group" aria-label="Filter the gallery by category"></div>');
        var $status = $('<p class="filter-status" aria-live="polite"></p>');

        function addButton(key, label, count) {
            $('<button type="button" class="filter-btn"></button>')
                .attr('data-filter', key)
                .attr('aria-pressed', key === 'all' ? 'true' : 'false')
                .text(label + ' (' + count + ')')
                .appendTo($bar);
        }

        addButton('all', 'All', $items.length);

        order.forEach(function (key) {
            if (counts[key]) {
                addButton(key, labels[key], counts[key]);
            }
        });

        Object.keys(counts).forEach(function (key) {
            if (order.indexOf(key) === -1) {
                addButton(key, key.charAt(0).toUpperCase() + key.slice(1), counts[key]);
            }
        });

        function updateStatus(shown) {
            $status.text('Showing ' + shown + ' of ' + $items.length + ' photos');
        }

        updateStatus($items.length);
        $grid.before($bar, $status);

        var filterToken = 0;

        $bar.on('click', '.filter-btn', function () {
            var $btn = $(this);
            var key = $btn.attr('data-filter');
            var token = ++filterToken;

            $bar.find('.filter-btn').attr('aria-pressed', 'false');
            $btn.attr('aria-pressed', 'true');

            var $show = key === 'all' ? $items : $items.filter('[data-category="' + key + '"]');
            var $hide = $items.not($show);

            updateStatus($show.length);

            $hide.stop(true, true).fadeOut(180).promise().done(function () {
                if (token === filterToken) {
                    $show.stop(true, true).fadeIn(260);
                }
            });
        });
    }


    // 6. Lightbox - built with JavaScript, opens when a gallery photo is clicked
    function initLightbox() {
        var grid = document.querySelector('.gallery-grid');
        if (!grid) {
            return;
        }

        var images = Array.prototype.slice.call(grid.querySelectorAll('img'));

        images.forEach(function (img) {
            img.setAttribute('tabindex', '0');
            img.setAttribute('role', 'button');
            img.setAttribute('aria-label', 'View larger: ' + (img.alt || 'photo'));
        });

        var overlay = document.createElement('div');
        overlay.className = 'lightbox';
        overlay.hidden = true;
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-label', 'Image viewer');
        overlay.innerHTML =
            '<button type="button" class="lightbox-close" aria-label="Close image viewer">\u00d7</button>' +
            '<button type="button" class="lightbox-prev" aria-label="Previous image">\u2039</button>' +
            '<figure class="lightbox-figure">' +
                '<img class="lightbox-img" alt="">' +
                '<figcaption class="lightbox-caption"></figcaption>' +
            '</figure>' +
            '<button type="button" class="lightbox-next" aria-label="Next image">\u203a</button>';
        document.body.appendChild(overlay);

        var bigImg = overlay.querySelector('.lightbox-img');
        var caption = overlay.querySelector('.lightbox-caption');
        var closeBtn = overlay.querySelector('.lightbox-close');
        var prevBtn = overlay.querySelector('.lightbox-prev');
        var nextBtn = overlay.querySelector('.lightbox-next');

        var visible = [];
        var index = 0;
        var lastFocused = null;
        var closeTimer = null;

        function getVisibleImages() {
            return images.filter(function (img) {
                return img.offsetParent !== null;
            });
        }

        function show(i) {
            index = (i + visible.length) % visible.length;
            var img = visible[index];
            bigImg.src = img.currentSrc || img.src;
            bigImg.alt = img.alt;
            caption.textContent = (img.alt || 'Photo') + ' (' + (index + 1) + ' of ' + visible.length + ')';
        }

        function open(img) {
            visible = getVisibleImages();
            var start = visible.indexOf(img);
            if (start === -1) {
                return;
            }

            clearTimeout(closeTimer);
            lastFocused = document.activeElement;
            prevBtn.hidden = nextBtn.hidden = visible.length < 2;
            show(start);

            overlay.hidden = false;
            document.body.style.overflow = 'hidden';
            requestAnimationFrame(function () {
                overlay.classList.add('is-open');
            });
            closeBtn.focus();
        }

        function close() {
            overlay.classList.remove('is-open');
            document.body.style.overflow = '';
            closeTimer = setTimeout(function () {
                overlay.hidden = true;
            }, 250);
            if (lastFocused) {
                lastFocused.focus();
            }
        }

        grid.addEventListener('click', function (e) {
            var img = e.target.closest('img');
            if (img && grid.contains(img)) {
                open(img);
            }
        });

        grid.addEventListener('keydown', function (e) {
            if ((e.key === 'Enter' || e.key === ' ') && e.target.tagName === 'IMG') {
                e.preventDefault();
                open(e.target);
            }
        });

        closeBtn.addEventListener('click', close);
        prevBtn.addEventListener('click', function () { show(index - 1); });
        nextBtn.addEventListener('click', function () { show(index + 1); });

        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) {
                close();
            }
        });

        document.addEventListener('keydown', function (e) {
            if (overlay.hidden) {
                return;
            }

            if (e.key === 'Escape') {
                close();
            } else if (e.key === 'ArrowLeft' && visible.length > 1) {
                show(index - 1);
            } else if (e.key === 'ArrowRight' && visible.length > 1) {
                show(index + 1);
            } else if (e.key === 'Tab') {
                var focusable = [closeBtn, prevBtn, nextBtn].filter(function (btn) {
                    return !btn.hidden;
                });
                var first = focusable[0];
                var last = focusable[focusable.length - 1];

                if (e.shiftKey && document.activeElement === first) {
                    e.preventDefault();
                    last.focus();
                } else if (!e.shiftKey && document.activeElement === last) {
                    e.preventDefault();
                    first.focus();
                }
            }
        });
    }


    // 7. Interactive map (Leaflet + OpenStreetMap) on the Contact page
    function initMap() {
        var mapEl = document.getElementById('map');
        if (!mapEl || typeof L === 'undefined') {
            return;
        }

        // Central Johannesburg - replace with your exact studio coordinates
        var position = [-26.2041, 28.0473];

        var map = L.map(mapEl, { scrollWheelZoom: false }).setView(position, 12);

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        L.marker(position)
            .addTo(map)
            .bindPopup('<strong>CineMe Productions</strong><br>Johannesburg, South Africa')
            .openPopup();

        // Scroll-wheel zoom only after the visitor clicks the map
        map.on('click', function () { map.scrollWheelZoom.enable(); });
        map.on('mouseout', function () { map.scrollWheelZoom.disable(); });
    }


// CineMe Productions - 5-second logo transition

(function () {
    'use strict';

    var DISPLAY_TIME = 4500;
    var FADE_TIME = 500;
    var isNavigating = false;

    // Find the correct logo path for each page.
    var isNavigationPage = window.location.pathname.toLowerCase().indexOf('/navigation/') !== -1;

    var logoPath = isNavigationPage
        ? 'images/cineme-logo-transparent.png.png'
        : 'images/cineme-logo-transparent.png.png';


    // Create the logo screen.
    function createSplash() {

        var splash = document.createElement('div');

        splash.className = 'cineme-splash';
        splash.setAttribute('role', 'status');
        splash.setAttribute('aria-label', 'CineMe Productions');

        var logo = document.createElement('img');

        logo.src = logoPath;
        logo.alt = 'CineMe Productions logo';
        logo.className = 'cineme-splash-logo';

        splash.appendChild(logo);
        document.body.appendChild(splash);

        window.requestAnimationFrame(function () {
            splash.classList.add('is-visible');
        });

        return splash;
    }


    // Show the logo for five seconds.
    function showSplash(afterClear) {

        document.documentElement.classList.add('cineme-splash-pending');

        var splash = createSplash();

        window.setTimeout(function () {

            splash.classList.add('is-leaving');

            window.setTimeout(function () {

                if (splash.parentNode) {
                    splash.parentNode.removeChild(splash);
                }

                document.documentElement.classList.remove('cineme-splash-pending');

                if (typeof afterClear === 'function') {
                    afterClear();
                }

            }, FADE_TIME);

        }, DISPLAY_TIME);
    }


    // Check whether the previous page already showed the logo.
    var skipSplash = false;

    try {

        skipSplash = sessionStorage.getItem('cinemeSkipSplash') === 'true';

        if (skipSplash) {
            sessionStorage.removeItem('cinemeSkipSplash');
        }

    } catch (error) {
        skipSplash = false;
    }


    // Avoid showing the logo twice when changing pages.
    if (skipSplash) {

        document.documentElement.classList.remove('cineme-splash-pending');

    } else {

        showSplash();

    }


    // Show the logo before opening another page.
    document.addEventListener('click', function (event) {

        var link = event.target.closest('a[href]');

        if (!link || isNavigating || event.defaultPrevented) {
            return;
        }

        if (event.button !== 0 || event.ctrlKey || event.shiftKey ||
            event.altKey || event.metaKey) {
            return;
        }

        if (link.target && link.target !== '_self') {
            return;
        }

        if (link.hasAttribute('download')) {
            return;
        }

        var destination = new URL(link.href, window.location.href);

        // Only use the transition for pages on this website.
        if (destination.origin !== window.location.origin ||
            !/\.html?$/i.test(destination.pathname)) {
            return;
        }

        // Ignore links that stay on the same page.
        if (destination.pathname === window.location.pathname &&
            destination.search === window.location.search) {
            return;
        }

        event.preventDefault();

        isNavigating = true;

        try {
            sessionStorage.setItem('cinemeSkipSplash', 'true');
        } catch (error) {
            // Navigation can still continue if storage is unavailable.
        }

        showSplash(function () {
            window.location.href = destination.href;
        });

    });

})();

    // Start everything
    markCurrentPage();
    initReveal();
    initLightbox();
    initMap();

    if (window.jQuery) {
        var $ = window.jQuery;

        if (prefersReduced) {
            $.fx.off = true;
        }

        $(function () {
            initAccordion($);
            initGalleryFilter($);
        });
    }
    
})();